<?php
$db = new SQLite3("db.sqlite");
$db->exec("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)");
$db->exec("INSERT INTO users (username, password) VALUES ('admin', '1234')");
echo "ثبت‌نام با موفقیت انجام شد.";
?>
