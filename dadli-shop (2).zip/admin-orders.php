<?php
$db = new SQLite3("db.sqlite");
$res = $db->query("SELECT * FROM orders");
echo "<h2>سفارش‌های ثبت‌شده</h2><ul>";
while ($row = $res->fetchArray()) {
  echo "<li>" . $row["name"] . " - کارت: " . $row["card"] . "</li>";
}
echo "</ul>";
?>
