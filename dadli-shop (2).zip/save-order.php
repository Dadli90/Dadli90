<?php
$db = new SQLite3("db.sqlite");
$db->exec("CREATE TABLE IF NOT EXISTS orders (name TEXT, card TEXT)");
$name = $_POST["name"];
$card = $_POST["card"];
$db->exec("INSERT INTO orders (name, card) VALUES ('$name', '$card')");
echo "سفارش شما ثبت شد!";
?>
