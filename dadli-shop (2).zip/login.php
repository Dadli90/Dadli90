<?php
$db = new SQLite3("db.sqlite");
$user = $_POST["user"];
$pass = $_POST["pass"];
$res = $db->query("SELECT * FROM users WHERE username='$user' AND password='$pass'");
if ($res->fetchArray()) {
  echo "ورود موفقیت‌آمیز بود";
} else {
  echo "اطلاعات نادرست است";
}
?>
